﻿namespace tms.Model
{
    public class SpResult
    {
        public string Result { get; set; }
        public string Message { get; set; }
    }
}