﻿
namespace tms.Config
{
    public class SeatGenerationResult
    {
        public string Result { get; set; }
        public string Message { get; set; }
    }
}
